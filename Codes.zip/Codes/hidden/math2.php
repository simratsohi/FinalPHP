<html>
	<head>
	</head>
	<body>
		<?php include('header.php');?>
		<form action="result.php" method="post">
			Number3: <input type="text" name="num2">
			<input type="hidden"  name="num"value="<?php echo $_POST['num']; ?>">
			<input type="hidden"  name="num1"value="<?php echo $_POST['num1'];?>">
			
			<input type="submit" name="submit" value="continue">
			
		</form>
	</body>
</html>