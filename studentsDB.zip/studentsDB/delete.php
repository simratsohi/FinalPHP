<?php
    include('connect.php');
    $delete_record=$_GET['delete'];

    $sql="delete from mytb where id=$delete_record";

    if($conn->query($sql)===TRUE)
    {
        echo "<script>alert('RECORD DELETED SUCCESSFULLY')</script>";
        include('view.php');
        exit();
    }
    else 
    {
        echo "ERROR DELETING RECORD: ". $conn->error;
    }
?>
    