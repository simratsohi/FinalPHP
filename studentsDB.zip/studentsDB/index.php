<?php
    include('connect.php');
?>
<html>
	<head>
		<title>
		
		</title>
	</head>
	<body>
        
	<form action="." method="post">
		<label>FIRST NAME</label><input type="text" name="fname"><br>
		<label>LAST NAME</label><input type="text" name="lname"><br>
		<label>Email:</label><input type="text" name="email"><br>
		<input type="submit" value="SUBMIT" name="submit"><br>
        <a href="view.php">VIEW DATA</a>
	</form>	
	</body>
</html>
<?php
    if(isset($_POST['submit']))
     {
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $email=$_POST['email'];
        
        //INSERT THE DATA INTO THE DATABASE
        $sql="insert into mytb(fname,lname,email) values('$fname','$lname','$email')";
    if($conn->query($  sql) === TRUE)
        {
            echo"<script>alert('NEW RECORD HAS BEEN ADDED SUCCESSFULLY')</script>";
        }
        else 
        {
            echo"ERROR: ".$sql."<br>".$conn->error;
        }
    }
?>