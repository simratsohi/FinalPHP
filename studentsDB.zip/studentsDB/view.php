<?php
    include('connect.php');
?>
<html>
    <head></head>
    <body>
        <h1>RECORD</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>FIRST NAME</th>
                <th>LAST NAME</th>
                <th>EMAIL</th>
                <th>DELETE</th>
                <th>UPDATE</th>
            </tr>
        <?php
            $sql="select * from mytb";
            $result=$conn->query($sql);
                if($result->num_rows>0)
                {
                    while($rows=$result->fetch_assoc())
                    {
         ?>
                    <tr>
                        <td><?php echo $rows['id'];?></td>
                        <td><?php echo $rows['fname'];?></td>
                        <td><?php echo $rows['lname'];?></td>
                        <td><?php echo $rows['email'];?></td>
                        <td><a href="delete.php?delete=<?php echo $rows['id']?>">DELETE</a></td>
                        <td><a href="edit.php">EDIT</a></td>
                    </tr>
            <?php      
                    }
                }
            
                else
                {
                    echo"NO RESULT";
                }
            ?>
            
        </table>
    </body>
</html>