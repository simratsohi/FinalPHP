<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$mydb = "students";
	
	// CREATE CONNECTION.
	
	$conn = new mysqli($servername,$username,$password,$mydb);
	
	//CHECK CONNECTION
	
	if($conn->connect_error)
	{
		die("Connection Failed: ". $conn->connect_error);
	}
	
	
?>