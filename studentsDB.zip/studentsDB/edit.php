<?php
    include('connect.php');
    $edit_record=$_GET['edit'];

$sql1="select * from mytb where id=$edit_record";
$result=$conn->query($sql1);

if($row=$result->fetch_assoc())
{
    $edit_id=$row['id'];
    $fname=$row['fname'];
    $lname=$row['lname'];
    $email=$row['email'];
}
?>
<html>
	<head>
		<title>
		
		</title>
	</head>
	<body>
        
	<form action="." method="post">
        <h1>UPDATE FORM</h1>
		<label>FIRST NAME</label><input type="text" name="fname"><br>
		<label>LAST NAME</label><input type="text" name="lname"><br>
		<label>Email:</label><input type="text" name="email"><br>
		<input type="submit" value="SUBMIT" name="submit"><br>
        <a href="view.php">VIEW DATA</a>
	</form>	
	</body>
</html>