<?php 
include("connect.php");
?>
<html>

<body>

    <table>
    <tr>
    
        <th>id</th>
        <th>name</th>
        <th>lastname</th>
        <th>email</th>
        <th>delete</th>
        <th>edit</th>
        
    </tr>
    
        <?php
            $sql="select * from final";
        
        $result=$conn->query($sql);
        if($result->num_rows>0){
            while($row=$result->fetch_assoc()){
                ?>
        <tr>
        
        <td><?php echo $row['id'] ?></td>
        <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['lastname'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><a href="delete.php?delete=<?php echo $row['id'] ;?> ">delete</a></td>
            <td><a href="edit.php?edit=<?php echo     $row['id'] ;?> ">edit</a></td>
        </tr>
        <?php
            }
        }else{
            echo "no records";
        }
        
        ?>
        
    </table>
    
</body>
</html>