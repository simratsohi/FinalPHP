<?php include("connect.php"); ?>
<html>

<body>
<a href="view.php">view</a>
    <form method="post">
    
    <label>name</label><input type="text" name="name"><br>
    <label>lastname</label><input type="text" name="lname"><br>    
    <label>email</label><input type="text" name="email"><br>
        <input type="submit" value="submit" name="submit">
        
        
    </form>
    
</body>
</html>
<?php

if(isset($_POST['submit'])){
    
    
    $name=$_POST['name'];
    $lastname=$_POST['lname'];
    $email=$_POST['email'];
    
    $sql = "insert into final(name,lastname,email)
    values('$name','$lastname','$email')";
    
    
    if($conn->query($sql)===TRUE){
    echo "<script>alert('new record created')</script>";
      }else{
    echo "error :".$sql.$conn->error;
     }

    
}


?>