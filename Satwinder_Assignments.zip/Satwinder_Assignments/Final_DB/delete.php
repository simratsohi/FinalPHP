<?php
include("connect.php");
$delete=$_GET['delete'];
$sql="delete from final where id = $delete";
if($conn->query($sql)===TRUE){
    echo "<script>alert('record deleted')</script>";
    include("view.php");
    exit();
}else{
    echo "error :".$conn->connect_error;
}
?>
