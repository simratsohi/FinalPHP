<?php

$servername="localhost";
$username="root";
$password="";
$database="final";

$conn=new mysqli($servername,$username,$password,$database);

if($conn->connect_error){
    die("connectio failed :".$conn->connect_error);
}

?>