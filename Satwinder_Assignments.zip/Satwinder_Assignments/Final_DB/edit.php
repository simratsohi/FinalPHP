<?php
include("connect.php");
$edit=$_GET['edit'];
$sql1="slect * from final where id=$edit";
$result=$conn->query($sql1);

if($row = $result->fetch_assoc()){
    $edit=$row['id'];
    $name=$row['name'];
    $lastname=$row['lname'];
    $email=$row['email'];
}


?>
<html>

<body>
    <h1>updateform</h1>
<a href="view.php">view</a>
    <form method="post">
    
    <label>name</label><input type="text" name="name"><br>
    <label>lastname</label><input type="text" name="lname"><br>    
    <label>email</label><input type="text" name="email"><br>
        <input type="submit" value="edit" name="edit">
        
        
    </form>
    
</body>
</html>