<style>
    body{
        background-color: azure;
    }
.bar{
            font-family: courier;
            margin-left: 11.5%;
            overflow: hidden;
            width:100%;
            margin-top: 3%;
            margin-left: 20%;
        }
        .bar a{
            float: left;
            display: block;
            color: white;
            background-color:dodgerblue;
            text-align: center;
            text-decoration: none;
            padding: 25px;
            font-size: 25px;
        }
        .bar a:hover{
            transition: 0.5s;
            opacity: 0.9;
           color:azure;
        }
        

</style>
<header>

 <div class="bar">
       <img src="logo.png" class="logo" height="70" width="250">
        <a href="index.php">Home</a>
        <a href="portfolio.php">About Us</a>
        <a href="about.php">Licence</a>
        <a href="about.php">Contact</a>
       
    
    </div> 



</header>