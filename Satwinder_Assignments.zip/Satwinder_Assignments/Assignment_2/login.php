<?php
include('header.php');
include('dblicense.php');

?>


<html>
<body>
      <h1>Log-in</h1>
    <form action="licence.php">
            <label>Username :</label><input type="text" name="usernamelogin"><br><br>
            <label>Password :</label><input type="password" name="passwordlogin"><br><br>
            <input type="submit" name="login" value="Log-in">
    </form>
    
    
</body>
</html>



<style>
    h1{
        margin-top: 4%;
        margin-left: 30%;
    }
    form{
        margin-left: 30%;
    }
</style>