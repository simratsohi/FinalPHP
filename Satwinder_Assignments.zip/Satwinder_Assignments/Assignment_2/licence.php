<?php
include('header.php');
include('dblicense.php');
?>
<html>
<body>
      <h1>Details</h1>
    <form method="post" action="view.php">
            <label>Licence No. :</label><input type="text" name="licencenumber"><br><br>
            <label>UserName :</label><input type="text" name="usernamelicence"><br><br>
            <label>Age (years) :</label><input type="text" name="age"><br><br>
            <label>Phone :</label><input type="text" name="phone"><br><br>
            <label>Address :</label><input type="text" name="address"><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
<?php
            if(isset($_POST['submit'])){   
                $licenceno=$_POST['licencenumber'];
                $username=$_POST['usernamelicence'];
                $age=$_POST['age'];
                $phone=$_POST['phone'];
                $address=$_POST['address'];
                $sql="insert into information(LicenceNo,Username,Age,Phone,Address)
                values('$licenceno','$username','$age','$phone','$address')";
                if($conn -> query($sql)===TRUE){
                    echo "<script>alert('new record is created')</script>";
                }else{
                    echo "error :" .$sql ." <br>". $conn->error;
                }
            }
?>
<style>
    h1{
        margin-top: 4%;
        margin-left: 30%;
    }
    form{
        margin-left: 30%;
    }
</style>