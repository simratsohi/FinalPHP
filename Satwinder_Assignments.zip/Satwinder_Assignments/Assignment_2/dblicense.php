<?php
$server="localhost";
$username="root";
$password="";
$mydb="licence";
$conn = new mysqli($server,$username,$password,$mydb);
if($conn -> connect_error){
    die("Connection error: " .$conn -> connect_error);
}
?>