<?php
include('header.php');
include('dblicense.php');
?>
<html>
<body>
    <h1>Manage Licence Data</h1>
    <table border="1">    
        <tr>

            <th>LicenceNo</th>
            <th>Username</th>
            <th>Age(Years)</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Delete</th>

        </tr>
    <?php
        $sql="select * from information";
        $result = $conn -> query($sql);        
        if($result->num_rows>0){
            while($row=$result->fetch_assoc()){
                ?>
                <tr>

                    <td id="id"><?php echo $row['LicenceNo']; ?></td>
                    <td><?php echo $row['Username']; ?></td>
                    <td><?php echo $row['Age']; ?></td>
                    <td><?php echo $row['Phone']; ?></td>
                    <td><?php echo $row['Address']; ?></td>
                    <td><a href="delete.php? delete=<?php echo $row['LicenceNo'] ?>">Delete</a></td>
                </tr>
            <?php
            }
        }else{
            echo "no data exists";
        }
        ?>
    </table>
</body>
</html>
<style>
    h1{
        margin-top: 3%;
        margin-left: 22%;
    }
    table{
        margin-left: 20%;
    }

</style>