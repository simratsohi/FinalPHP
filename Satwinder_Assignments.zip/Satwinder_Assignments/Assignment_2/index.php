<?php
include('header.php');
include('dblicense.php');
?>
<html>
<body>
      <h1>Registration Form</h1>
    <form method="post" action=".">
            <label>Username :</label><input type="text" name="username"><br><br>
            <label>Email :</label><input type="text" name="Email"><br><br>        
            <label>Password :</label><input type="password" name="password"><br><br>
            <label>RePassword :</label><input type="password" name="repassword"><br><br>
            <input type="submit" name="register" value="Register">
            <button value="Log-in" formaction="login.php">Log-in</button>
    </form>
</body>
</html>
<?php
            if(isset($_POST['register'])){   
                $username=$_POST['username'];
                $email=$_POST['Email'];
                $password=$_POST['password'];
                $repassword=$_POST['repassword'];
                $sql="insert into mytable (username,email,password)
                values('$username','$email','$password')";
                if($conn -> query($sql)===TRUE){
                    echo "<script>alert('new record is created')</script>";
                }else{
                    echo "error :" .$sql ." <br>". $conn->error;
                }
            }
?>
<style>
    h1{
        margin-top: 4%;
        margin-left: 30%;
    }
    form{
        margin-left: 30%;
    }
</style>