<?php
include('dblicense.php');
$delete_record=$_GET['delete'];
$sql="delete from mytable where id = $delete_record";
if($conn -> query($sql) === TRUE){
    echo"<script>alert('record deleted successfully')</script>";
    include('view.php');
    exit();
}else{
    echo "error deleting record :". $conn->error;
}
?>